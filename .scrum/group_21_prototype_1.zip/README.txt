Virtual Environment
-------------------

	- Have Python 3 installed

	- Open Command Prompt (or equivalent - if python isn't accessible from environment variables, use absolute path to python.exe)

	- Navigate to target root directory of the prototype

	- "python -m venv webtech-env" to create the environment

	- "webtech-env\Scripts\activate.bat" to activate the environment

	- "pip install -r requirements.txt" to install required libraries (~400mb) to the virtual environment



Prototype
---------

	- Have the 'webtech-env' virtual environment activated

	- Run 'python app/flask_app.py' to start the app server on port 5000

	- Open url 'localhost:5000' from a web browser


Features
--------
	
	- Website wrapping all other features	

	- Upload of .csv files in adjacency matrix format

	- Selecting / closing an uploaded file for visualization (file selection persists between sessions)

	- Visualization Bokeh dashboard, including:
		- placeholder settings tabs
		- node-link view with one ordering algorithm (circular)
		- adjacency matrix without any ordering
		- basic exploration interactions (pan, zoom, hover, node / edge select)